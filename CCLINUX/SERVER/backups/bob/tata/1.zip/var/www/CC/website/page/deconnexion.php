<?php
/*
** deconnexion.php for deconnexion.php in /private/var/folders/0b/_nssthn11mxcdv80q42ht5th1d_q77/T/e27d72d8-6bb4-4411-b51c-7ba97ce88c50/var/www/CC/website/page/deconnexion.php
**
** Made by MOREAU Julien
** Login   <moreau_j@etna-alternance.net>
**
** Started on Mon Jan 25 09:08:39 2016 MOREAU Julien
** Last update Mon Jan 25 09:08:39 2016 MOREAU Julien
*/
if (isset($_SESSION["connect_ID"]))
{
  session_destroy();
?>
<div id="content-home">
  <div class="container">
    <div class="row">
      <div class="col-md-offset-3 col-md-6">
        <div class="alert alert-info center" role="alert">
          Déconnexion réussi, redirection en cours.
        </div>
      </div>
    </div>
  </div>
</div>
<?php } ?>
<meta http-equiv="refresh" content="1; URL=?p=home">
