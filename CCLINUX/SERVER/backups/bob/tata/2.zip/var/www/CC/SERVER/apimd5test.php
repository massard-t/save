<h1>Inscription</h1>
<div class="content_text">
  <form method="post" action="api.php" enctype="multipart/form-data" id="inscriptions">
    <div class="form-group">
      <center><label for="file">Photo de profil</label></center>
      <center><div id="file_preview">
        <div class="thumbnail hidden">
          <img src="http://placehold.it/5" alt="" style="max-width:100%;max-height:400px;">
          <div class="caption">
            <h4></h4>
            <p></p>
          </div>
        </div>
      </div></center>
      <div class="fileUpload btn btn-primary">
        <span>Ajouter votre photo</span>
        <input type="text" name="md5" id="userfile"/>
        <input type="text" name="path" id="path"/>
      </div>
    </div>
    <input class="form-control btn btn-primary" type="submit" value="S'inscrire">
  </div>
</form>
