<?php
require("db.php");

function errorcode($number){
	$error[1] = "Error on move of uploaded file";
	$error[2] = "File already exists";
	$error[3] = "File corrupted";
	$error[4] = "Error on modification time change";
	$error[5] = "User not exists";
	$error[6] = "Where is your file ?!";
	$error[7] = "PASSWORD PAS BON";
	$error[8] = "Error on uncompression";
	$error[9] = "No change !";
	$error[403] = "No data !";
	return $error[$number];
}

function error($number){
	if ((int)$number > 0){
		$return['success'] = FALSE;
		$return['errorcode'] = $number;
		$return['errorname'] = errorcode($number);
	}
	else
		$return['success'] = TRUE;
	return ($return);
}

function pathcreator($path){
	$path = explode("/", $path);
	foreach ($path as $key => $value) {
		if (isset($tmp))
			unset($tmp);
		for ($i=0; $i <= (int)$key; $i++) {
			if (isset($tmp))
				$tmp .= "/".$path[$i];
			else
				$tmp = $path[$i];
		}
		if (isset($tmp) && $tmp != ""){
			if (!file_exists($tmp))
				mkdir($tmp);
		}
	}
	if (!file_exists($tmp.'/current'))
		mkdir($tmp.'/current');
	return $tmp;
}

function subpathcreator($path){
	$path = explode("/", $path);
	foreach ($path as $key => $value) {
		if (isset($tmp))
			unset($tmp);
		for ($i=0; $i < (int)$key; $i++) {
			if (isset($tmp))
				$tmp .= "/".$path[$i];
			else
				$tmp = $path[$i];
		}
		if (isset($tmp) && $tmp != ""){
			if (!file_exists($tmp))
				mkdir($tmp);
		}
	}
}

function folddel($path){
	$files = array_diff(scandir($path), array('.','..'));
	foreach ($files as $file) {
		if (is_dir("$path/$file"))
			folddel("$path/$file");
		else
			unlink("$path/$file");
	}
	rmdir($path);
}

function removecurrentemptyfolders($path){
	$version = version($path);
	if (is_dir($path)){
		$files = array_diff(scandir($path), array('.','..'));
		foreach ($files as $file) {
			if (is_dir("$path/$file"))
				removecurrentemptyfolders("$path/$file");
		}
	}
	if (is_dir($path) &&
		count(array_diff(scandir("$path"), array('.','..'))) == 0){
		rmdir($path);
	logversion(0, 0, $path);
}
}

function version($dir){
	$idir = preg_replace("#current.*#", "", $dir);
	$i = 0;
	while (file_exists($idir.++$i.".zip"));
	$version = --$i;
	return ($version);
}

function comparemain($dir, $ff, $version){
	$bak = $dir.'/'.$ff;
	$new = str_replace("current", "tmp", $dir).'/'.$ff;
	if ($ff != "version.log" && !file_exists($new)){
		$pattern = "/version.log";
		$replace = preg_replace("#\/current.*$#", $pattern, $dir);
		if (file_exists($bak) && !is_dir($bak)){
			unlink($bak);
			logversion(1, 0, $dir."/".$ff);
		}
	}
	if(is_dir($dir.'/'.$ff) && $ff != "."){
		compare($dir.'/'.$ff);
	}
	if (!file_exists(str_replace("current", "tmp", $dir))){
		removecurrentemptyfolders($dir);
	}
}

function compare($dir){
	$version = version($dir);
	$ffs = scandir($dir);
	foreach($ffs as $ff){
		if($ff != '.' && $ff != '..'){
			comparemain($dir, $ff, $version);
		}
	}
}

function versionid($dir){
	$user = explode("/", preg_replace("#.*backups/#", "", $dir));
	$query = "SELECT * FROM `users` WHERE name = '".$user[0]."'";
	$userid = db()->query($query)->fetch();
	$query = "SELECT * FROM `backup` WHERE Name = '".$user[count($user)-2];
	$query .= "' AND User = ".$userid['id'];
	$versionid = db()->query($query)->fetch();
	return ($versionid['ID']);
}

function logversion($type, $change, $new){
	$dir = preg_replace("#current.*#", "", $new);
	$version = version($dir."/current");
	$idback = versionid($dir);
	$new = preg_replace("#.*current#", "", $new);
	if ($type == 0)
		$terms = "DOSSIER ";
	else
		$terms = "FICHIER ";
	if ($change == 1)
		$terms .= "AJOUTE";
	elseif ($change == 2)
		$terms .= "MODIFIE";
	else
		$terms .= "SUPPRIME";
	$txt = $version.",".$type.",".$change.",".$terms.",".$new."\n";
	file_put_contents ($dir."/version.log",$txt, FILE_APPEND);
	$tmp = "INSERT INTO modification (Backup, Version, Type, Changed, Path)";
	$req = db()->prepare($tmp." VALUES (:back, :vers, :type, :change, :path)");
	$req->execute(array(
		"back" => $idback,
		"vers" => $version,
		"type" => $type,
		"change" => $change,
		"path" => $new
		));
}

function unzipboucle($zip, $i, $stat, $dir){
	$new = $dir."/current/".$stat['name'];
	$bak = $dir."/tmp/".$stat['name'];
	if (file_exists($new) && file_exists($bak)){
		if ($stat['crc'] == hexdec(hash_file('crc32b', $bak))){
			if (!is_dir($bak))
				unlink($bak);
			$zip->deleteIndex($i);
		}
		else {
			logversion(1, 2, $new);
			rename($bak, $new);
		}
	}
	else{
		if (file_exists($bak)){
			if (is_file($bak)){
				logversion(1, 1, $new);
				rename($bak, $new);
			}
			else {
				logversion(0, 1, $new);
				subpathcreator($new);
			}
		}
	}
}

function unzip($finalpath,$dir){
	$zip = new ZipArchive;
	if ($zip->open($finalpath) === TRUE) {
		$zip->extractTo($dir."/tmp");
		compare($dir."/current");
		for( $i = 0; $i < $zip->numFiles; $i++ ){
			$stat = $zip->statIndex($i);
			unzipboucle($zip, $i, $stat, $dir);
		}
		$zip->close();
		folddel($dir."/tmp");
	}
}

function initiateversion($user, $path, $i, $data){
	$backpath = getcwd()."/backups/".$user."/backup.log";
	if ($i == 1){
		file_put_contents($backpath, $path."/\n", FILE_APPEND);
		$query = "SELECT * FROM `backup` WHERE Name = '".basename($path)."'";
		$query .= " AND User = '".$data['user']['id']."'";
		$rslt = db()->query($query)->fetch();
		if (count($rslt) <= 1){
			$req = db()->prepare("INSERT INTO backup (Name, User)".
				"VALUES (:name, :user)");
			$req->execute(array(
				"name" => basename($path),
				"user" => $data['user']['id']
				));
		}
	}
}

function pathuser($data, $file){
	$user = $data['username'];
	$path = $data['path'];
	$finalpath = getcwd()."/backups/".$user.$path;
	$finalpath = pathcreator($finalpath);
	$i = 0;
	while (file_exists($finalpath."/".++$i.".zip"));
	initiateversion($user, $path, $i, $data);
	$dir = $finalpath;
	$finalpath .= "/".$i.".zip";
	if (!file_exists($finalpath)){
		if (move_uploaded_file($file["tmp_name"], $finalpath)){
			unzip($finalpath,$dir);
			if (file_exists($finalpath))
				return(error(0));
			else
				return(error(9));
		}
		else
			return(error(1));
	}
	else
		return(error(2));
}

// echo "<pre>";
// print_r($_FILES);
// echo "</pre>";
// echo "<pre>";
// print_r($_POST);
// echo "</pre>";
if (isset($_POST['username'])){
	$query = "SELECT * FROM `users` WHERE name = '".$_POST['username']."'";
	$_POST['user'] = db()->query($query)->fetch();
}
if (count($_POST) == 0)
	$return = error(403);
elseif (!isset($_POST['user']) || !isset($_POST['user']['name']))
	$return = error(5);
elseif ($_POST['user']['password'] != $_POST['password'])
	$return = error(7);
elseif (count($_FILES) < 1)
	$return = error(6);
elseif (md5_file($_FILES[array_keys($_FILES)[0]]['tmp_name']) != $_POST['md5'])
	$return = error(3);
else {
	if (!isset($_POST['path']))
		$_POST['path'] = "/".$_POST['name'];
	$file = $_FILES[array_keys($_FILES)[0]];
	$return = pathuser($_POST, $file);
}
$return = json_encode($return);
echo $return;
?>