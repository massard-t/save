#  url = http://92.222.227.175:1234/main.php
import requests


#r = requests.post("http://92.222.227.175:1234/main.php", data={"username":"toto", "mac":"00:0a:95:9d:68:16", "path":"/var/www/tataa", "timestamp":"1354457962", "md5":"d4bf666f5b50b9b64d81d0e1e45a1a44"})
class file_to_send(self):
	"""Get informations about the file to send"""
	def __init__(self):
		super(file_to_send, self).__init__()

	def md5(filename):
	    hash = hashlib.md5()
	    with open(filename, "rb") as f:
	        for chunk in iter(lambda: f.read(4096), b""):
	            hash.update(chunk)
	    return hash.hexdigest()



class send_files(self):
	"""Class to list files"""
	def __init__(self, filename):
		super(send_files, self).__init__()
		self.filename = filename

	def add_file(self, file_to_send):

		pass
# print(r.content)
