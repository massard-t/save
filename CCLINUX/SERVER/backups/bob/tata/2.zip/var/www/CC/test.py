from time import *


def test(arg1, arg2):
    str = "hello"
    i = 0
    while i < 10:
        print str
        i = i + 1

        test("test", "test")
