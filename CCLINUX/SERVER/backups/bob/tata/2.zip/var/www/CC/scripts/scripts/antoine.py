#!/usr/bin/python3.4
import os
import os.path
import tarfile
import sys
import requests
import time


def send_file(filename):
    r = requests.post("http://92.222.227.175:1234/main.php",  files={filename: open(filename, 'rb')})
    print(r.content)
    pass

def make_tarfile(source_dir):
    timestamp = str(time.time())
    filename = timestamp+".tar.gz"
    with tarfile.open(filename, "w:gz") as tar:
        tar.add(source_dir, arcname=os.path.basename(source_dir))
    pass
    return filename


if __name__ == '__main__':
    send_file(make_tarfile(sys.argv[1]))
