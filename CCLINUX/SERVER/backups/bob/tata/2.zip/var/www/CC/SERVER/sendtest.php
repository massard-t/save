<h1>Inscription</h1>
<div class="content_text">
  <form method="post" action="main.php" enctype="multipart/form-data" id="inscriptions">
    <div class="form-group">
      <center><label for="file">Photo de profil</label></center>
      <center><div id="file_preview">
        <div class="thumbnail hidden">
          <img src="http://placehold.it/5" alt="" style="max-width:100%;max-height:400px;">
          <div class="caption">
            <h4></h4>
            <p></p>
          </div>
        </div>
      </div></center>
      <p><button type="button" class="btn btn-default btn-danger cancelfile hidden">Retirer cette photo</button></p>
      <div class="fileUpload btn btn-primary">
        <span>Ajouter votre photo</span>
        <input type="file" class="upload" name="connect_py" id="userfile"/>
      </div>
    </div>
    <input class="form-control btn btn-primary" type="submit" value="S'inscrire">
  </div>
</form>
