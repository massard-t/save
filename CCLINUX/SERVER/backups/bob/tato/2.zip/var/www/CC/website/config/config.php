<?php
/*
** config.php for config.php in /private/var/folders/0b/_nssthn11mxcdv80q42ht5th1d_q77/T/e27d72d8-6bb4-4411-b51c-7ba97ce88c50/var/www/CC/website/config/config.php
**
** Made by MOREAU Julien
** Login   <moreau_j@etna-alternance.net>
**
** Started on Mon Jan 25 09:08:39 2016 MOREAU Julien
** Last update Mon Jan 25 09:08:39 2016 MOREAU Julien
*/
  /*Logs bdd*/
  $host = 'localhost';
  $dbname = 'backito';
	$user = 'backitoto';
  $passwd = 'a7VSJ29umQMwHY4j';
