<!DOCTYPE html>
  <html>
    <head>
      <meta charset="UTF-8">
      <title>Backito</title>
      <link href="style/css/bootstrap.css" rel="stylesheet">
      <link href="style/css/global.css" rel="stylesheet">
      <script src="js/highlight.pack.js"></script>
      <link rel="stylesheet" href="style/css/github.css">
      <script>
   hljs.tabReplace = '    ';
   hljs.lineNodes = true;
   hljs.initHighlightingOnLoad();
   </script>
   <script src="js/highlightjs.loader.min.js"></script>
    </head>
